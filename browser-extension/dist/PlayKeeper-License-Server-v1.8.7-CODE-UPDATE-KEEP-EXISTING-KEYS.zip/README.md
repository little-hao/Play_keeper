# Play Keeper v1.8.7 授权服务器

该目录由插件所有者保管，不能随扩展 ZIP 分发。`private-key.pem` 是签名私钥；扩展只包含对应公钥。

## 本地验证

1. 安装 Node.js 18 或更高版本。
2. 按需修改 `server-config.json` 中的激活码、设备上限和令牌时长。
3. 运行 `start-license-server.ps1`。
4. 浏览器访问 `http://127.0.0.1:8787/health` 应返回 `ok: true`。
5. 将扩展 `license-config.js` 的 `enabled` 改为 `true`，重新加载扩展。
6. 在神宠规划器许可证区域输入配置中的激活码。

## 正式部署

- 必须放在 HTTPS 反向代理后面，不要直接暴露本地 HTTP 服务。
- 修改扩展 `license-config.js` 的 `serverBaseUrl`，并在 `manifest.json` 的 `host_permissions` 中加入同一域名。
- 正式部署前重新生成 P-256 密钥对，并替换服务器私钥及扩展公钥。
- 备份运行后生成的 `license-state.json`；删除某设备记录后可以允许换机。
- 使用 Caddy 等可信反向代理时保持 `trustProxy: true`，服务器会记录转发后的访问 IP；直接暴露 Node 服务时应设为 `false`。
- 设备记录包含自定义名称、备注、系统、浏览器、插件版本、架构、IP、首次激活、最后活动和停用状态。
- 停用单台设备时，将 `license-state.json` 对应记录的 `disabled` 改为 `true` 并重启服务；客户端不能修改停用状态。
- 可使用 `node manage-devices.js list` 查看设备，或使用 `disable`、`enable`、`note`、`name` 命令管理指定设备。
- 不要把服务器目录、私钥、激活码清单或状态文件放进扩展 ZIP。
