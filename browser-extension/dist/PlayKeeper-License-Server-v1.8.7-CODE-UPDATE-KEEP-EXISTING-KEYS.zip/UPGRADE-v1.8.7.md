# v1.8.7 生产服务器升级

升级前备份服务器目录，尤其保留以下生产文件：

- `private-key.pem`
- `server-config.json`
- `license-state.json`

只替换 `server.js`、`manage-devices.js`、`package.json` 和说明文件。不要用其他环境的密钥、激活码配置或设备状态覆盖生产文件。

在生产 `server-config.json` 顶层增加：

```json
"trustProxy": true
```

该配置适用于当前 Caddy HTTPS 反向代理。更新后运行 `node --check server.js`，再通过 PM2 重启服务并访问 `/health`，返回的 `serverVersion` 应为 `1.8.7`。

现有 `license-state.json` 不需要手工迁移。设备在下一次激活或续签时会自动补齐新字段。
