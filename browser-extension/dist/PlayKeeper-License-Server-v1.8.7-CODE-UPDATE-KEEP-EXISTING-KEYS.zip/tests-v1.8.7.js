"use strict";

const fs = require("fs");
const path = require("path");
const assert = require("assert/strict");

const root = __dirname;
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const server = fs.readFileSync(path.join(root, "server.js"), "utf8");

assert.equal(pkg.version, "1.8.7");
assert.match(server, /const SERVER_VERSION = "1\.8\.7"/);
assert.match(server, /function requestIp/);
assert.match(server, /firstActivatedAt/);
assert.match(server, /lastActivityAt/);
assert.match(server, /device\.disabled/);
assert.match(server, /browserVersion/);
assert.match(server, /extensionVersion/);
assert.match(server, /publicDevice/);

console.log("license server v1.8.7 device record checks passed");
