"use strict";

const fs = require("fs");
const path = require("path");

const statePath = path.join(__dirname, "license-state.json");
if (!fs.existsSync(statePath)) throw new Error("license-state.json 尚未生成");
const state = JSON.parse(fs.readFileSync(statePath, "utf8"));
const [command = "list", licenseId = "", installationId = "", ...rest] = process.argv.slice(2);
const devices = licenseId ? (state.devices?.[licenseId] || []) : Object.values(state.devices || {}).flat();
const target = devices.find((item) => item.installationId === installationId);

if (command === "list") {
  const rows = [];
  for (const [currentLicenseId, currentDevices] of Object.entries(state.devices || {})) {
    for (const device of currentDevices) {
      rows.push({
        licenseId: currentLicenseId,
        installationId: device.installationId,
        deviceName: device.deviceName || "",
        os: [device.osName, device.osVersion].filter(Boolean).join(" "),
        browser: [device.browserName, device.browserVersion].filter(Boolean).join(" "),
        extensionVersion: device.extensionVersion || "",
        ipAddress: device.ipAddress || "",
        firstActivatedAt: device.firstActivatedAt || device.firstSeen || "",
        lastActivityAt: device.lastActivityAt || device.lastSeen || "",
        disabled: Boolean(device.disabled),
        note: device.note || "",
      });
    }
  }
  console.table(rows);
  process.exit(0);
}

if (!licenseId || !installationId || !target) throw new Error("未找到指定 licenseId / installationId 的设备");
if (command === "disable") target.disabled = true;
else if (command === "enable") target.disabled = false;
else if (command === "note") target.note = rest.join(" ").trim().slice(0, 240);
else if (command === "name") target.deviceName = rest.join(" ").trim().slice(0, 80);
else throw new Error("命令仅支持 list、disable、enable、note、name");
target.ownerUpdatedAt = new Date().toISOString();
fs.writeFileSync(statePath, `${JSON.stringify(state, null, 2)}\n`, "utf8");
console.log(`设备 ${installationId} 已执行 ${command}`);
