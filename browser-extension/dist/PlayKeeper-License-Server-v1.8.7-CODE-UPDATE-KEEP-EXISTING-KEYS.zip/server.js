"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const root = __dirname;
const config = JSON.parse(fs.readFileSync(path.join(root, "server-config.json"), "utf8"));
const privateKey = fs.readFileSync(path.join(root, "private-key.pem"), "utf8");
const statePath = path.join(root, "license-state.json");
const state = fs.existsSync(statePath)
  ? JSON.parse(fs.readFileSync(statePath, "utf8"))
  : { devices: {} };
const SERVER_VERSION = "1.8.7";

const base64url = (value) => Buffer.from(value).toString("base64url");
const jsonPart = (value) => base64url(JSON.stringify(value));
const saveState = () => fs.writeFileSync(statePath, `${JSON.stringify(state, null, 2)}\n`, "utf8");
const licenseByCode = (code) => config.licenses.find((item) => item.active && item.activationCode === code);
const licenseById = (id) => config.licenses.find((item) => item.active && item.licenseId === id);

function signToken(payload) {
  const payloadPart = jsonPart(payload);
  const signature = crypto.sign("sha256", Buffer.from(payloadPart), {
    key: privateKey,
    dsaEncoding: "ieee-p1363",
  });
  return `${payloadPart}.${signature.toString("base64url")}`;
}

function verifyToken(token) {
  const parts = String(token || "").split(".");
  if (parts.length !== 2) throw new Error("令牌格式无效");
  const valid = crypto.verify("sha256", Buffer.from(parts[0]), {
    key: crypto.createPublicKey(privateKey),
    dsaEncoding: "ieee-p1363",
  }, Buffer.from(parts[1], "base64url"));
  if (!valid) throw new Error("令牌签名无效");
  return JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
}

function issueToken(license, installationId, device) {
  const now = Date.now();
  return signToken({
    productId: config.productId,
    licenseId: license.licenseId,
    installationId,
    issuedAt: now,
    expiresAt: now + Number(config.tokenHours || 72) * 60 * 60 * 1000,
    minVersion: config.minVersion || "1.5.0",
    deviceName: device?.deviceName || "",
  });
}

const cleanText = (value, maxLength) => String(value || "").trim().slice(0, maxLength);

function requestIp(request) {
  const forwarded = config.trustProxy ? String(request.headers["x-forwarded-for"] || "").split(",")[0].trim() : "";
  return cleanText(forwarded || request.socket.remoteAddress || "", 80);
}

function applyDeviceMetadata(device, metadata, ipAddress, now) {
  const source = metadata && typeof metadata === "object" ? metadata : {};
  const assign = (key, maxLength) => {
    if (Object.hasOwn(source, key)) device[key] = cleanText(source[key], maxLength);
  };
  assign("deviceName", 80);
  assign("note", 240);
  assign("osName", 60);
  assign("osVersion", 40);
  assign("browserName", 60);
  assign("browserVersion", 40);
  assign("extensionVersion", 24);
  assign("architecture", 24);
  assign("bitness", 12);
  assign("model", 80);
  device.ipAddress = cleanText(ipAddress, 80);
  device.lastActivityAt = now;
  device.lastSeen = now;
  if (typeof device.disabled !== "boolean") device.disabled = false;
  return device;
}

function publicDevice(device) {
  return {
    installationId: device.installationId,
    deviceName: device.deviceName || "",
    osName: device.osName || "",
    osVersion: device.osVersion || "",
    browserName: device.browserName || "",
    browserVersion: device.browserVersion || "",
    extensionVersion: device.extensionVersion || "",
    firstActivatedAt: device.firstActivatedAt || device.firstSeen || "",
    lastActivityAt: device.lastActivityAt || device.lastSeen || "",
    disabled: Boolean(device.disabled),
  };
}

function registerDevice(license, installationId, metadata, ipAddress) {
  const devices = state.devices[license.licenseId] ||= [];
  const existing = devices.find((item) => item.installationId === installationId);
  const now = new Date().toISOString();
  if (existing) {
    if (existing.disabled) throw new Error("当前设备已被授权所有者停用");
    if (!existing.firstActivatedAt) existing.firstActivatedAt = existing.firstSeen || now;
    applyDeviceMetadata(existing, metadata, ipAddress, now);
    saveState();
    return existing;
  }
  const activeDevices = devices.filter((item) => !item.disabled);
  if (activeDevices.length >= Number(license.maxDevices || 1)) throw new Error(`该授权已达到 ${license.maxDevices || 1} 台设备上限`);
  const created = applyDeviceMetadata({ installationId, firstActivatedAt: now, firstSeen: now, disabled: false }, metadata, ipAddress, now);
  devices.push(created);
  saveState();
  return created;
}

function touchRegisteredDevice(license, installationId, metadata, ipAddress) {
  const devices = state.devices[license.licenseId] || [];
  const existing = devices.find((item) => item.installationId === installationId);
  if (!existing) throw new Error("当前安装实例未在该授权中登记");
  if (existing.disabled) throw new Error("当前设备已被授权所有者停用");
  const now = new Date().toISOString();
  if (!existing.firstActivatedAt) existing.firstActivatedAt = existing.firstSeen || now;
  applyDeviceMetadata(existing, metadata, ipAddress, now);
  saveState();
  return existing;
}

function send(response, status, value) {
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-headers": "content-type",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "cache-control": "no-store",
  });
  response.end(JSON.stringify(value));
}

function readBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 32_768) reject(new Error("请求内容过大"));
    });
    request.on("end", () => {
      try { resolve(JSON.parse(body || "{}")); } catch (_) { reject(new Error("JSON 请求格式无效")); }
    });
    request.on("error", reject);
  });
}

const server = http.createServer(async (request, response) => {
  if (request.method === "OPTIONS") return send(response, 204, {});
  if (request.method === "GET" && request.url === "/health") {
    return send(response, 200, { ok: true, serverVersion: SERVER_VERSION, productId: config.productId, minVersion: config.minVersion });
  }
  if (request.method !== "POST" || !["/v1/activate", "/v1/refresh"].includes(request.url)) {
    return send(response, 404, { error: "接口不存在" });
  }
  try {
    const body = await readBody(request);
    if (body.productId !== config.productId) throw new Error("产品标识不匹配");
    if (!String(body.installationId || "").trim()) throw new Error("缺少安装实例标识");
    let license;
    let device;
    const ipAddress = requestIp(request);
    const deviceMetadata = {
      ...(body.device && typeof body.device === "object" ? body.device : {}),
      extensionVersion: body.device?.extensionVersion || body.extensionVersion || "",
    };
    if (request.url === "/v1/activate") {
      license = licenseByCode(String(body.activationCode || "").trim());
      if (!license) throw new Error("激活码无效或已停用");
      device = registerDevice(license, body.installationId, deviceMetadata, ipAddress);
    } else {
      const oldPayload = verifyToken(body.token);
      if (oldPayload.productId !== config.productId || oldPayload.installationId !== body.installationId) {
        throw new Error("续签身份与原许可证不一致");
      }
      license = licenseById(oldPayload.licenseId);
      if (!license) throw new Error("授权已停用");
      device = touchRegisteredDevice(license, body.installationId, deviceMetadata, ipAddress);
    }
    return send(response, 200, { token: issueToken(license, body.installationId, device), device: publicDevice(device) });
  } catch (error) {
    return send(response, 403, { error: error.message || String(error) });
  }
});

server.listen(Number(config.port || 8787), config.host || "127.0.0.1", () => {
  console.log(`Play Keeper license server listening on http://${config.host || "127.0.0.1"}:${config.port || 8787}`);
});
