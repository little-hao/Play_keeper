import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { once } from "node:events";
import { WebSocket } from "ws";
import { createRelayServer } from "../server.js";
import { AuthStore } from "../auth-store.js";

const adminToken = "test-admin-token-123456789";
const deviceToken = "test-device-token-12345678";

function connect(url) {
  const socket = new WebSocket(url);
  return once(socket, "open").then(() => socket);
}

function nextJson(socket, expectedType, timeout = 3000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Timed out waiting for ${expectedType}`)), timeout);
    function onMessage(buffer) {
      const message = JSON.parse(buffer.toString());
      if (message.type !== expectedType) return;
      clearTimeout(timer);
      socket.off("message", onMessage);
      resolve(message);
    }
    socket.on("message", onMessage);
  });
}

test("assigned device accounts are persisted to the matching remote user", async (context) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "play-keeper-sync-"));
  const authFile = path.join(directory, "users.json");
  const token = "frost-device-token-20261018";
  const store = new AuthStore(authFile, adminToken);
  const frost = store.authenticate("霜冻前夜", "20261016", "", token);
  store.updateSettings(frost, { accountLabels: ["hao", "hao1", "hao2", "hao3"],
    mainAccount: "hao", planSchedule: { enabled: false, time: "04:00",
      timeZone: "Asia/Shanghai", options: {
        routeLabels: ["hao", "hao1", "hao2", "hao3", "hao"] } } });
  const server = createRelayServer({ adminToken, deviceToken, authFile,
    planScheduleFile: path.join(directory, "schedule.json"),
    logger: { warn() {}, error() {} } });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  const port = server.address().port;
  const device = await connect(`ws://127.0.0.1:${port}/device`);
  const control = await connect(`ws://127.0.0.1:${port}/control`);
  context.after(async () => {
    device.terminate();
    control.terminate();
    await new Promise((resolve) => server.close(resolve));
    fs.rmSync(directory, { recursive: true, force: true });
  });

  const deviceAccepted = nextJson(device, "device.accepted");
  device.send(JSON.stringify({ type: "device.hello", deviceId: "PK-FROST123456",
    token, appVersion: "2.0.2-rc2" }));
  await deviceAccepted;
  const controlAccepted = nextJson(control, "control.accepted");
  const initialSettings = nextJson(control, "user.settings");
  control.send(JSON.stringify({ type: "control.hello", username: "霜冻前夜",
    password: "20261016", deviceToken: token }));
  await controlAccepted;
  await initialSettings;

  const updatedSettings = nextJson(control, "user.settings");
  device.send(JSON.stringify({ type: "telemetry.update", payload: { accounts: [
    { index: 0, label: "杂鱼小弟" }, { index: 1, label: "杂鱼小妹" },
    { index: 2, label: "合宠糕手" }, { index: 3, label: "涅槃糕手" }
  ] } }));
  const update = await updatedSettings;
  assert.deepEqual(update.payload.accountLabels,
    ["杂鱼小弟", "杂鱼小妹", "合宠糕手", "涅槃糕手"]);
  assert.deepEqual(update.payload.planSchedule.options.routeLabels,
    ["杂鱼小弟", "杂鱼小妹", "合宠糕手", "涅槃糕手", "杂鱼小弟"]);
});

test("device telemetry and browser command complete a round trip", async (context) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "play-keeper-protocol-"));
  const server = createRelayServer({ adminToken, deviceToken,
    authFile: path.join(directory, "users.json"),
    planScheduleFile: path.join(directory, "schedule.json"),
    logger: { warn() {}, error() {} } });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  const port = server.address().port;

  const device = await connect(`ws://127.0.0.1:${port}/device`);
  const control = await connect(`ws://127.0.0.1:${port}/control`);
  context.after(async () => {
    device.terminate();
    control.terminate();
    await new Promise((resolve) => server.close(resolve));
    fs.rmSync(directory, { recursive: true, force: true });
  });

  const deviceAccepted = nextJson(device, "device.accepted");
  device.send(JSON.stringify({
    type: "device.hello", deviceId: "PK-ABCDEF123456", token: deviceToken, appVersion: "1.2.0"
  }));
  await deviceAccepted;

  const controlAccepted = nextJson(control, "control.accepted");
  const snapshotPromise = nextJson(control, "devices.snapshot");
  control.send(JSON.stringify({ type: "control.hello", token: adminToken }));
  await controlAccepted;
  const snapshot = await snapshotPromise;
  assert.equal(snapshot.devices[0].deviceId, "PK-ABCDEF123456");

  const telemetryPromise = nextJson(control, "telemetry.update");
  device.send(JSON.stringify({
    type: "telemetry.update", timestamp: Date.now(), payload: { battery: { levelPercent: 88 } }
  }));
  const telemetry = await telemetryPromise;
  assert.equal(telemetry.payload.battery.levelPercent, 88);

  const requestPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "switch_account",
    parameters: { accountIndex: 2 }
  }));
  const request = await requestPromise;
  assert.equal(request.command, "switch_account");
  assert.equal(request.parameters.accountIndex, 2);

  const resultPromise = nextJson(control, "command.result");
  device.send(JSON.stringify({
    type: "command.result", commandId: request.commandId, success: true, message: "账号已切换"
  }));
  const result = await resultPromise;
  assert.equal(result.success, true);
  assert.equal(result.commandId, request.commandId);

  const startPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "preview_start",
    parameters: { accountIndex: 2, maxWidth: 720, fps: 1 }
  }));
  const start = await startPromise;
  assert.equal(start.command, "preview_start");

  const previewPromise = nextJson(control, "preview.frame");
  device.send(JSON.stringify({
    type: "preview.frame",
    timestamp: Date.now(),
    payload: {
      accountIndex: 2,
      accountLabel: "测试用户",
      sequence: 7,
      width: 720,
      height: 400,
      mime: "image/jpeg",
      blackOverlay: true,
      imageBase64: Buffer.from("fake-jpeg").toString("base64")
    }
  }));
  const preview = await previewPromise;
  assert.equal(preview.payload.accountLabel, "测试用户");
  assert.equal(preview.payload.sequence, 7);

  const interactionPromise = nextJson(control, "interaction.select");
  device.send(JSON.stringify({
    type: "interaction.select",
    timestamp: Date.now(),
    payload: {
      accountIndex: 2,
      accountLabel: "测试用户",
      elementToken: "pk_test_123",
      title: "地图",
      selectedIndex: 1,
      options: [
        { index: 0, label: "新手基地", selected: false, disabled: false },
        { index: 1, label: "圣兽云殿", selected: true, disabled: false }
      ]
    }
  }));
  const interaction = await interactionPromise;
  assert.equal(interaction.payload.title, "地图");
  assert.equal(interaction.payload.options[1].label, "圣兽云殿");

  const selectionPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "select_option",
    parameters: { accountIndex: 2, elementToken: "pk_test_123", optionIndex: 0 }
  }));
  const selection = await selectionPromise;
  assert.equal(selection.command, "select_option");
  assert.equal(selection.parameters.optionIndex, 0);

  const tapPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "pointer_tap",
    parameters: { accountIndex: 2, x: 0.25, y: 0.75, frameSequence: 7 }
  }));
  const tap = await tapPromise;
  assert.equal(tap.command, "pointer_tap");
  assert.equal(tap.parameters.x, 0.25);

  const swipePromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "pointer_swipe",
    parameters: { accountIndex: 2, x1: 0.5, y1: 0.8, x2: 0.5, y2: 0.2,
      durationMs: 420, frameSequence: 7 }
  }));
  const swipe = await swipePromise;
  assert.equal(swipe.command, "pointer_swipe");
  assert.equal(swipe.parameters.durationMs, 420);

  const automationPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_auto_auction",
    parameters: {
      accountIndex: 2,
      enabled: true,
      items: ["进化宝石", "曙光印记"],
      buyer: "hao",
      intervalHours: 12
    }
  }));
  const automation = await automationPromise;
  assert.equal(automation.command, "configure_auto_auction");
  assert.deepEqual(automation.parameters.items, ["进化宝石", "曙光印记"]);

  const storeSellPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_store_sell",
    parameters: { accountIndex: 2, enabled: true, items: ["金币券"], intervalHours: 12 }
  }));
  const storeSell = await storeSellPromise;
  assert.equal(storeSell.command, "configure_store_sell");
  assert.deepEqual(storeSell.parameters.items, ["金币券"]);

  const warehousePromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_warehouse_sync",
    parameters: { accountIndex: 2, enabled: true, item: "护宠仙石" }
  }));
  const warehouse = await warehousePromise;
  assert.equal(warehouse.command, "configure_warehouse_sync");
  assert.equal(warehouse.parameters.item, "护宠仙石");

  const warehouseRunPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "run_warehouse_sync",
    parameters: { accountIndex: 2 }
  }));
  const warehouseRun = await warehouseRunPromise;
  assert.equal(warehouseRun.command, "run_warehouse_sync");

  const warehouseComboPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_warehouse_sync",
    parameters: { accountIndex: 2, enabled: true, items: ["护宠仙石", "雨露结晶"] }
  }));
  const warehouseCombo = await warehouseComboPromise;
  assert.deepEqual(warehouseCombo.parameters.items, ["护宠仙石", "雨露结晶"]);

  const dungeonPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_dungeon_sequence",
    parameters: { accountIndex: 2, items: ["绘画小屋", "伊苏王的神墓"],
      skill: "毒咬 · 伤害", completeTasks: true }
  }));
  const dungeon = await dungeonPromise;
  assert.deepEqual(dungeon.parameters.items, ["绘画小屋", "伊苏王的神墓"]);
  assert.equal(dungeon.parameters.skill, "毒咬 · 伤害");
  assert.equal(dungeon.parameters.completeTasks, true);

  const adventurePromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_adventure",
    parameters: { accountIndex: 2, map: "圣诞小屋" }
  }));
  const adventure = await adventurePromise;
  assert.equal(adventure.parameters.map, "圣诞小屋");

  for (const command of ["run_auto_capture", "run_tower_battle"]) {
    const runPromise = nextJson(device, "command.request");
    control.send(JSON.stringify({
      type: "command.send",
      deviceId: "PK-ABCDEF123456",
      command,
      parameters: { accountIndex: 2 }
    }));
    assert.equal((await runPromise).command, command);
  }

  const prestigePromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_prestige_items",
    parameters: { accountIndex: 2, enabled: true, items: ["黑暗徽章", "黑暗宝石"] }
  }));
  const prestige = await prestigePromise;
  assert.equal(prestige.parameters.enabled, true);
  assert.deepEqual(prestige.parameters.items, ["黑暗徽章", "黑暗宝石"]);

  const inventoryPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_inventory_monitor",
    parameters: {
      accountIndex: 2,
      items: ["进化宝石", "曙光印记", "强化丹A", "强化丹B", "天仙玉露"]
    }
  }));
  const inventory = await inventoryPromise;
  assert.equal(inventory.command, "configure_inventory_monitor");
  assert.equal(inventory.parameters.items.at(-1), "天仙玉露");

  const keepPlayerStartPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "keep_player_start",
    parameters: {}
  }));
  const keepPlayerStart = await keepPlayerStartPromise;
  assert.equal(keepPlayerStart.command, "keep_player_start");

  const equipmentPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "configure_equipment_transfer",
    parameters: {
      accountIndex: 2,
      items: ["厄菲斯神剑", "厄菲斯神铠", "厄菲斯神冠", "厄菲斯神靴", "厄菲斯神链",
        "厄菲斯神戒", "厄菲斯神翼", "厄菲斯神镯", "厄菲斯神玉", "厄菲斯神印", "卡片甲", "卡片乙"],
      price: 920,
      buyer: "buyer@id"
    }
  }));
  const equipment = await equipmentPromise;
  assert.equal(equipment.command, "configure_equipment_transfer");
  assert.equal(equipment.parameters.price, 920);
  assert.equal(equipment.parameters.buyer, "buyer@id");
  assert.equal(equipment.parameters.items.length, 12);

  const auctionBuyPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "run_auction_buy",
    parameters: { accountIndex: 2 }
  }));
  const auctionBuy = await auctionBuyPromise;
  assert.equal(auctionBuy.command, "run_auction_buy");

  const templeConfirmationPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "resolve_temple_confirmation",
    parameters: { accountIndex: 2, enterTemple: true }
  }));
  const templeConfirmation = await templeConfirmationPromise;
  assert.equal(templeConfirmation.command, "resolve_temple_confirmation");
  assert.equal(templeConfirmation.parameters.enterTemple, true);

  const verifyPromise = nextJson(device, "command.request");
  const verificationToken = "12345678-1234-4123-8123-123456789abc";
  control.send(JSON.stringify({ type: "command.send", deviceId: "PK-ABCDEF123456",
    command: "confirm_equipment_verification", parameters: { accountIndex: 2, verificationToken } }));
  const verification = await verifyPromise;
  assert.equal(verification.command, "confirm_equipment_verification");
  assert.equal(verification.parameters.verificationToken, verificationToken);

  const completedTasksPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "run_completed_tasks",
    parameters: { accountIndex: 2 }
  }));
  const completedTasks = await completedTasksPromise;
  assert.equal(completedTasks.command, "run_completed_tasks");
  assert.equal(completedTasks.parameters.accountIndex, 2);

  const cancelPromise = nextJson(device, "command.request");
  control.send(JSON.stringify({
    type: "command.send",
    deviceId: "PK-ABCDEF123456",
    command: "cancel_automation",
    parameters: { accountIndex: 2 }
  }));
  const cancel = await cancelPromise;
  assert.equal(cancel.command, "cancel_automation");

  const automaticStopPromise = nextJson(device, "command.request");
  control.close();
  const automaticStop = await automaticStopPromise;
  assert.equal(automaticStop.command, "preview_stop");
});

test("invalid tokens and invalid commands are rejected", async (context) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "play-keeper-invalid-"));
  const server = createRelayServer({ adminToken, deviceToken,
    authFile: path.join(directory, "users.json"),
    planScheduleFile: path.join(directory, "schedule.json"),
    logger: { warn() {}, error() {} } });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  const port = server.address().port;

  const rejected = await connect(`ws://127.0.0.1:${port}/control`);
  const rejectionPromise = nextJson(rejected, "control.rejected");
  rejected.send(JSON.stringify({ type: "control.hello", token: "wrong" }));
  await rejectionPromise;

  const control = await connect(`ws://127.0.0.1:${port}/control`);
  context.after(async () => {
    rejected.terminate();
    control.terminate();
    await new Promise((resolve) => server.close(resolve));
    fs.rmSync(directory, { recursive: true, force: true });
  });
  const accepted = nextJson(control, "control.accepted");
  const snapshotPromise = nextJson(control, "devices.snapshot");
  control.send(JSON.stringify({ type: "control.hello", token: adminToken }));
  await accepted;
  await snapshotPromise;
  const whitelistErrorPromise = nextJson(control, "command.error");
  control.send(JSON.stringify({
    type: "command.send", deviceId: "missing", command: "configure_store_sell",
    parameters: { accountIndex: 0, enabled: true, items: ["进化宝石"], intervalHours: 12 }
  }));
  const whitelistError = await whitelistErrorPromise;
  assert.match(whitelistError.message, /无效/);

  const errorPromise = nextJson(control, "command.error");
  control.send(JSON.stringify({
    type: "command.send", deviceId: "missing", command: "switch_account",
    parameters: { accountIndex: 99 }
  }));
  const error = await errorPromise;
  assert.match(error.message, /无效/);
  const invalidRecoveryPromise = nextJson(control, "command.error");
  control.send(JSON.stringify({
    type: "command.send", deviceId: "missing", command: "run_equipment_buy",
    parameters: { accountIndex: 1, sellerAccountIndex: 4, recovery: true }
  }));
  assert.match((await invalidRecoveryPromise).message, /无效/);
  for (const verificationToken of ["", "-".repeat(36), "stale"] ) {
    const invalidConfirmation = nextJson(control, "command.error");
    control.send(JSON.stringify({ type: "command.send", deviceId: "missing",
      command: "confirm_equipment_verification", parameters: { accountIndex: 0, verificationToken } }));
    assert.match((await invalidConfirmation).message, /无效/);
  }
});

test("health endpoint and iPhone dashboard are served", async (context) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "play-keeper-health-"));
  const server = createRelayServer({ adminToken, deviceToken,
    authFile: path.join(directory, "users.json"),
    planScheduleFile: path.join(directory, "schedule.json"),
    logger: { warn() {}, error() {} } });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  const port = server.address().port;
  context.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    fs.rmSync(directory, { recursive: true, force: true });
  });

  const health = await fetch(`http://127.0.0.1:${port}/health`);
  assert.equal(health.status, 200);
  assert.deepEqual(await health.json(), {
    ok: true, service: "play-keeper-relay", version: "2.0.7"
  });

  const dashboard = await fetch(`http://127.0.0.1:${port}/`);
  assert.equal(dashboard.status, 200);
  const dashboardHtml = await dashboard.text();
  assert.match(dashboardHtml, /Play Keeper 远程控制/);
  assert.match(dashboardHtml, /拍卖道具/);
  assert.match(dashboardHtml, /卖出金币券/);
  assert.match(dashboardHtml, /背包自动存仓/);
  assert.match(dashboardHtml, /立即检查存仓/);
  assert.match(dashboardHtml, /中断脚本/);
  assert.match(dashboardHtml, /全选背包存仓/);
  assert.match(dashboardHtml, /指定买家按设定单价购买道具/);
  assert.match(dashboardHtml, /下载本用户报错说明/);
  assert.match(dashboardHtml, /拍卖选中账号道具到指定买家/);
  assert.match(dashboardHtml, /情人恋套装/);
  assert.match(dashboardHtml, /device_token/);
  assert.match(dashboardHtml, /该账号开始挂机/);
  assert.match(dashboardHtml, /今日执行与背包汇总/);
  assert.match(dashboardHtml, /多用户挂机/);
  assert.match(dashboardHtml, /完整默认循环（8个账号）/);
  assert.match(dashboardHtml, /装备定向转移单价/);
  assert.match(dashboardHtml, /道具拍卖\/购买单价/);
  assert.match(dashboardHtml, /每个账号返回的挂机副本/);
  assert.match(dashboardHtml, /启动 KeepPlayer/);
  assert.match(dashboardHtml, /天仙玉露/);
  assert.match(dashboard.headers.get("content-security-policy"), /object-src 'none'/);
});
